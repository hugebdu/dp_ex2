==========================Exercise Checking Report========================== 
Exercise No...........: 02
First Student Details.: 312717218 - Alexander Vainshtein
Second Student Details: 305870636 - Daniel Shmuglin
Delivery Date.........: 17 - Nov - 2013
Delivered In Delay....: No
Delay Reason..........: 
Comments..............: 
=======================End Exercise Checking Report=========================