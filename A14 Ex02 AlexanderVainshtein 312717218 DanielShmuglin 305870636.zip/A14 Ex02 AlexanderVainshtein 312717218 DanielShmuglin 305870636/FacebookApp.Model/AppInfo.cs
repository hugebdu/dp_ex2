﻿namespace Ex2.FacebookApp
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class AppInfo
    {
        public const string AppID = "537339166355791";
        public const string UserAboutMe = "user_about_me";
        public const string FriendsAboutMe = "friends_about_me";
        public const string PublishStream = "publish_stream";
        public const string UserEvents = "user_events";
        public const string ReadStrem = "read_stream";
        public const string UserStatus = "user_status";
    }
}